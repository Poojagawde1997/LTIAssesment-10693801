package com.example.SmartShop.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SmartShop.Dao.ProductRepository;
import com.example.SmartShop.Exception.ResourceNotFoundException;
import com.example.SmartShop.Model.Product;
import java.util.*;

@Service
public class ProductService {
	@Autowired
	ProductRepository prodrepo;
	
	public List<Product> getallproduct(){
		List<Product> list=new ArrayList<>();
		prodrepo.findAll().forEach(prod->list.add(prod));
		return list;
	}
	
	public void saveorupdate(Product product ) {
		prodrepo.save(product);
	}
	
	public Product getproductbyname(String name) {
		return prodrepo.findproductbyname(name);
	}
	
	public Product getproductbycategory(String category) {
		return prodrepo.findproductbycategory(category);
	}
	
	public String deleteproductbyrating(long id) throws ResourceNotFoundException {
		Product prod=prodrepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Product not found with id :"  +id));
		
		int rate=prod.getRating();
		if(rate<2) {
			prodrepo.deleteById(id);
			return "Product with id"+id+"is deleted"; 
		}
		return "Product with id :" +id+ "has rating more than 2";
		
		
	}
	
	public String CalculateTotalunitprice(long id) throws ResourceNotFoundException {
		Product prod=prodrepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Product with id :" +id+ "not found"));
		int unitp=prod.getUnitPrice();
		int qty=prod.getQuantity();
		int total=unitp*qty;
		prodrepo.updateexpiry(total,id);
		return "Total price calculated are :" +total;
	}
	
	
	
	
}
