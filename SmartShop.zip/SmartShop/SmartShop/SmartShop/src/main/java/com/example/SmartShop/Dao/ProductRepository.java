package com.example.SmartShop.Dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.SmartShop.Model.Product;

@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, Long> {
//    @Query("select t from Ticket t where t.email=:email")

	@Query("select c from Product c where  c.Name=:name  ")
	Product findproductbyname(String name);

	@Query("select c from Product c where  c.Category=:category  ")
	Product findproductbycategory(String category);

	
	@Modifying
	@Query("update Product c set c.totalPrice=?1 where c.productId=?2")
	void updateexpiry( int total,long id);

	

}
