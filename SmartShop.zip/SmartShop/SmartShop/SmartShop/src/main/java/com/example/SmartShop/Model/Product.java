package com.example.SmartShop.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="producttbl")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private long productId;
	@Column(name="name",nullable=false)
	private String Name;
	@Column(name="category",nullable=false)
	private String Category;
	@Column(name="quantity",nullable=false)
	private int Quantity;
	@Column(name="unitprice",nullable=false)
	private int unitPrice;
	@Column(name="rating",nullable=false)
	private int rating;
	@Column(name="totalprice")
	private int totalPrice;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(long productId, String name, String category, int quantity, int unitPrice, int rating,
			int totalPrice) {
		super();
		this.productId = productId;
		Name = name;
		Category = category;
		Quantity = quantity;
		this.unitPrice = unitPrice;
		this.rating = rating;
		this.totalPrice = totalPrice;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", Name=" + Name + ", Category=" + Category + ", Quantity="
				+ Quantity + ", unitPrice=" + unitPrice + ", rating=" + rating + ", totalPrice=" + totalPrice + "]";
	}
	
	
	
	
	
	
}
